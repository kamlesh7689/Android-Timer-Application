import java.util.*;
public class NumberToWordsConverter{  

    private static final String[] units = {  
            "", "one", "two", "three", "four",  
            "five", "six", "seven", "eight", "nine",  
            "ten", "eleven", "twelve", "thirteen", "fourteen",  
            "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"  
    };  

    private static final String[] tens = {  
            "", "", "twenty", "thirty", "forty",  
            "fifty", "sixty", "seventy", "eighty", "ninety"  
    };  

    private static final String[] thousands = {  
            "", "thousand", "million"  
    };  

    public static String convert(int number) {  
        if (number == 0) {  
            return "zero";  
        }  

        StringBuilder words = new StringBuilder();  

        int thousandIndex = 0;  

        while (number > 0) {  
            int segment = number % 1000;  
            if (segment > 0) {  
                String segmentInWords = convertSegment(segment);  
                words.insert(0, segmentInWords + (thousands[thousandIndex].isEmpty() ? "" : " " + thousands[thousandIndex]) + " ");  
            }  
            number /= 1000;  
            thousandIndex++;  
        }  

        return words.toString().trim();  
    }  

    private static String convertSegment(int number) {  
        StringBuilder segment = new StringBuilder();  

        if (number >= 100) {  
            segment.append(units[number / 100]).append(" hundred ");  
            number %= 100;  
        }  
        if (number >= 20) {  
            segment.append(tens[number / 10]).append(" ");  
            number %= 10;  
        }  
        if (number > 0) {  
            segment.append(units[number]).append(" ");  
        }  

        return segment.toString();  
    }  

    public static void main(String[] args) {  
        Scanner sc = new Scanner(System.in);  
        System.out.print("Enter a number (1 to 999,999,999): ");  
        int number = sc.nextInt();  

        if (number < 1 || number > 999999999) {  
            System.out.println("Number out of range.");  
        } else {  
            String result = convert(number);  
            System.out.println("Number in words: " + result);  
        }  

    }  
}